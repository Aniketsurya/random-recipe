<template lang="html">


  <input type="text" placeholder="Search your fav recipe..." v-model="dish">

  <div class="container" >
    <div class="container" v-for="meal in meals" :key="meal">
      <img :src="meal.strMealThumb" alt="{{meal.strMeal}}" height="200" width="400" >
      <router-link :to="{path: `/search/${meal.idMeal}`}">
        {{meal.strMeal}}
      </router-link>
    </div>
  </div>
</template>

<script>
import Axios from 'axios';

export default {
  name: 'SearchRecipe',
  data(){
    return{
      dish:'',
      meals:[]
    }
  },

  updated(){
    Axios.get('https://www.themealdb.com/api/json/v1/1/search.php?s='+ this.dish).then(response => {
      this.meals = response.data.meals;
      this.youtubeVideo = this.meal[0].strYoutube.substring(32);
      this.loading = false;
    }).catch(err => {
      this.err = 'Sorry for trouble. Something went wrong. Wait for sometime or try again later';
      console.log(err);
    });
  },
  methods:{

  }
}
</script>

<style lang="css" scoped>
</style>
