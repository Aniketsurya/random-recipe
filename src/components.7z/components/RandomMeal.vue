<template lang="html">
  <div class="card">
    <div class="buttonclass">
      <button type="button" name="randomMeal" @click="getMeal">
        <i class='fas fa-hamburger' style='font-size:48px;color:red'></i>
        Let's try Random Meal
      </button>
    </div>


    <div class="container">
      <h3 v-if="loading">Data loading...</h3>
      <div class="row align-items-start" v-else-if="err==='' && clicked">
        <div class="col-md-6">
       <img :src="meal[0].strMealThumb" alt="{{meal[0].strMeal}}" height="200" width="400" > 
       </div>
          {{meal[0].strMeal}}

          Ingredients

            v-for="ingredient in ingredients" :key="ingredient">
              {{ingredient}}


        Instructions
            {{meal[0].strInstructions}}

         <iframe width="1000" height="315" :src="'https://www.youtube.com/embed/' + youtubeVideo"></iframe>


      <h3 v-else>{{err}}</h3>
      </div>
    </div>

  </div>
</template>

<script>
import Axios from 'axios';

export default {
  name: 'RandomMeal',
  data(){
        return{
            meal:'',
            loading:false,
            err:'',
            clicked:false,
            youtubeVideo:'',
            ingredients:[]

        }
    },
    created(){
      /*Axios.get('https://www.themealdb.com/api/json/v1/1/random.php/').then(response => {
        this.meal = response.data.meals; //response.data.meals[0]
        this.youtubeVideo = this.meal[0].strYoutube.substring(32);
        this.loading = false;
        this.getIngredients();
      }).catch(err => {
        this.err = 'Sorry for trouble. Something went wrong. Wait for sometime or try again later';
        console.log(err);
      });*/
      this.getMealRandomComponent();
    },

    watch:{

    },

    methods:{
      getIngredients(){
        this.ingredients = [];
       /*for(let i = 0;i<20;i++){
          this.ingredients.push(`${this.meal[0].strIngredient${i}} - ${this.meal[0].strMeasure${i}}`);
        }*/

        this.ingredients.push(`${this.meal[0].strIngredient1}`);this.ingredients.push(`${this.meal[0].strIngredient2}`);this.ingredients.push(`${this.meal[0].strIngredient3}`);this.ingredients.push(`${this.meal[0].strIngredient4}`);
        this.ingredients.push(`${this.meal[0].strIngredient5}`);this.ingredients.push(`${this.meal[0].strIngredient6}`);this.ingredients.push(`${this.meal[0].strIngredient7}`);this.ingredients.push(`${this.meal[0].strIngredient8}`);
        this.ingredients.push(`${this.meal[0].strIngredient9}`);this.ingredients.push(`${this.meal[0].strIngredient10}`);this.ingredients.push(`${this.meal[0].strIngredient11}`);this.ingredients.push(`${this.meal[0].strIngredient12}`);
        this.ingredients.push(`${this.meal[0].strIngredient13}`);this.ingredients.push(`${this.meal[0].strIngredient14}`);this.ingredients.push(`${this.meal[0].strIngredient15}`);this.ingredients.push(`${this.meal[0].strIngredient16}`);
        this.ingredients.push(`${this.meal[0].strIngredient17}`);this.ingredients.push(`${this.meal[0].strIngredient18}`);this.ingredients.push(`${this.meal[0].strIngredient19}`);this.ingredients.push(`${this.meal[0].strIngredient20}`);
      },
      /*sleep(ms){
          return new Promise(resolve => setTimeout(resolve, ms));
      },*/
      async getMealRandomComponent(){
          var res = await Axios.get('https://www.themealdb.com/api/json/v1/1/random.php/').then(response => {
          this.meal = response.data.meals;
          this.youtubeVideo = this.meal[0].strYoutube.substring(32);
          this.loading = false;

          this.getIngredients();

        }).catch(err => {
          this.err = 'Sorry for trouble. Something went wrong. Wait for sometime or try again later';
          console.log(err);
        });
        //await this.sleep(10000);
        return res;
      },
      getMeal(){
        this.loading = true;
        if (this.clicked) {
          this.getMealRandomComponent();
        }
        this.clicked = true;
        console.log(this.ingredients);
      //  this.getIngredients();
        this.loading=false;
      },


    }
}
</script>

<style lang="css" scoped>
td,tr,th {
  text-align: center;
  vertical-align: middle;
}
table,th,tr,td{
  border: solid; margin: 10px; align:center;
}
.buttonclass{
  position: relative;
  left: 0;
  right: 0;
  margin-left: auto;
  margin-right: auto;
  width: 100px;
  height: auto;
}
button{
  color: inherit;
  border-radius: 5px;
  border-width: medium;
  border-color: green;

}
</style>
