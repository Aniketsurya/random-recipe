<template lang="html">
  <div class="">



      <SearchRecipe />

  </div>

  <hr>
  <div class="">
      <RandomMeal/>
  </div>

</template>

<script>
import SearchRecipe from './SearchRecipe.vue'
import RandomMeal from './RandomMeal.vue'

export default {
  name: "Home",
  components: {
    SearchRecipe,
    RandomMeal
  }
}
</script>

<style lang="css" scoped>
</style>
