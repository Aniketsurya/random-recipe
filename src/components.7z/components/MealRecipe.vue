<template lang="html">
  <div class="">

  <table>
  <tr>
    <td> <img :src="meal[0].strMealThumb" alt="{{meal[0].strMeal}}" height="200" width="400"> </td>
    <td>{{meal[0].strMeal}}</td>
   </tr>
  <tr >
    <th>Ingredients </th>
    <table>
      <tr v-for="ingredient in ingredients" :key="ingredient">
        {{ingredient}}
      </tr>
    </table>
  </tr>
  <tr>
    <th>Instructions</th>
    <td>
      {{meal[0].strInstructions}}
    </td>
  </tr>
  <tr ><th colspan="2"> <iframe width="1000" height="315" :src="'https://www.youtube.com/embed/' + youtubeVideo"></iframe></th></tr>
  
</table>

</div>
</template>

<script>
import Axios from 'axios';

export default {
  name: "MealRecipe",
  data(){
    return{
      dishid:this.$route.params.dishid,
      loading:false,
      err:'',
      youtubeVideo:'',
      meal:'',
      ingredients:[]
    }
  },
  created(){
    Axios.get('https://www.themealdb.com/api/json/v1/1/lookup.php?i='+ this.dishid).then(response => {
      this.meal = response.data.meals;
      this.youtubeVideo = this.meal[0].strYoutube.substring(32);
      this.loading = false;
      this.getIngredients();
    }).catch(err => {
      this.err = 'Sorry for trouble. Something went wrong. Wait for sometime or try again later';
      console.log(err);
    });

  },
  methods:{
    getIngredients(){
    //this.ingredients = [];
     for(let i = 0;i<20;i++){
        this.ingredients.push(`${this.meal[0].strIngredient+i.toString()} - ${this.meal[0].strMeasure+i.toString()}`);
        console.log(typeof(i.toString()));
      }

      /*this.ingredients.push(`${this.meal[0].strIngredient1}`);this.ingredients.push(`${this.meal[0].strIngredient2}`);this.ingredients.push(`${this.meal[0].strIngredient3}`);this.ingredients.push(`${this.meal[0].strIngredient4}`);
      this.ingredients.push(`${this.meal[0].strIngredient5}`);this.ingredients.push(`${this.meal[0].strIngredient6}`);this.ingredients.push(`${this.meal[0].strIngredient7}`);this.ingredients.push(`${this.meal[0].strIngredient8}`);
      this.ingredients.push(`${this.meal[0].strIngredient9}`);this.ingredients.push(`${this.meal[0].strIngredient10}`);this.ingredients.push(`${this.meal[0].strIngredient11}`);this.ingredients.push(`${this.meal[0].strIngredient12}`);
      this.ingredients.push(`${this.meal[0].strIngredient13}`);this.ingredients.push(`${this.meal[0].strIngredient14}`);this.ingredients.push(`${this.meal[0].strIngredient15}`);this.ingredients.push(`${this.meal[0].strIngredient16}`);
      this.ingredients.push(`${this.meal[0].strIngredient17}`);this.ingredients.push(`${this.meal[0].strIngredient18}`);this.ingredients.push(`${this.meal[0].strIngredient19}`);this.ingredients.push(`${this.meal[0].strIngredient20}`);*/
    },
  }
}
</script>

<style lang="css" scoped>
td,tr,th {
  text-align: center;
  vertical-align: middle;
}
table,th,tr,td{
  border: solid; margin: 10px; align:center;
}
</style>
